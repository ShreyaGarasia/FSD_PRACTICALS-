const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
const connectDB = require("./mongodb");
const mongoose = require("mongoose");

const app = express();
const PORT = 3000;

// Connect to MongoDB
connectDB();


app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));


const userSchema = new mongoose.Schema({
name: String,
email: { type: String, unique: true },
password: String
});

const User = mongoose.model("User", userSchema);


let loggedInUser = null;

// Sign Up
app.post("/signup", async (req, res) => {
const { name, email, password } = req.body;

try {
    const exists = await User.findOne({ email });
    if (exists) return res.send("User already exists. <a href='signup.js'>Try again</a>");

    const newUser = new User({ name, email, password });
    await newUser.save();
    res.send("Sign Up successful! <a href='signin.js'>Sign In</a>");
} catch (err) {
    console.log(err);
    res.send("Error occurred. <a href='signup.js'>Try again</a>");
}
});

// Sign In
app.post("/signin", async (req, res) => {
const { email, password } = req.body;

try {
    const user = await User.findOne({ email, password });
    if (user) {
    loggedInUser = user;
    res.redirect("/dashboard");
    } else {
    res.send("Invalid credentials. <a href='signin.html'>Try again</a>");
    }
} catch (err) {
    console.log(err);
    res.send("Error occurred. <a href='signin.html'>Try again</a>");
}
});


app.get("/dashboard", (req, res) => {
if (!loggedInUser) return res.redirect("/signin.js");
res.sendFile(path.join(__dirname, "public", "dashboard.js"));
});


app.post("/signout", (req, res) => {
loggedInUser = null;
res.redirect("/signin.js");
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));

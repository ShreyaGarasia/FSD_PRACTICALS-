import React from 'react';

function Dashboard() {
    return (
        <div>
            <h1>Welcome to the Dashboard</h1>
            <form action="/signout" method="POST">
                <button type="submit">Sign Out</button>
            </form>
        </div>
    );
}
export default Dashboard;

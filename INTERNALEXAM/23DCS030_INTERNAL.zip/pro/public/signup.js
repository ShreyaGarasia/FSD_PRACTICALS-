import react, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './signin.css';

function Signin(){
    const navigate = useNavigate();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:5000/api/signin', { email, password });
            if(response.data.success){
                navigate('/dashboard');
            } else {
                setError(response.data.message || 'Signin failed');
            }
        } catch (err) {
            setError('An error occurred. Please try again.');
        }
    };
    return (
        <div class="box">
    <h2>Sign Up</h2>
    <form action="/signup" method="POST">
    <input type="text" name="name" placeholder="Name" required />
    <input type="email" name="email" placeholder="Email" required />
    <input type="password" name="password" placeholder="Password" required />
    <button type="submit">Sign Up</button>
    </form>
    <p>Already have an account? <a href="signin.html">Sign In</a></p>
</div>
    );
}

export default Signin;